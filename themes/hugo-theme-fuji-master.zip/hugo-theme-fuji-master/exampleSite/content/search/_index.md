+++
title = "Search"
description = ""
+++

You can change search page details above.

Keep this file saft to ensure Hugo generate the search page.
